import java.util.Scanner;

public class LuasPersegiPanjang {


    public static void main(String []args){

        int p;
        int l;
        int L;

        Scanner keyboard = new Scanner(System.in);
        // new = kata ganti dari objek(Scanner)
        System.out.println("Program Hitung Luas");
        /*User Melakukan Input Data
         * 
         * Nama :...
         * Alamat :...
         */
        System.out.print("Masukkan Panjang :");
        p = Integer.parseInt(keyboard.nextLine());

        System.out.print("Masukkan Lebar :");
        l = Integer.parseInt(keyboard.nextLine());

        L = p*l;
        keyboard.close(); 
        /*Akan Menampilkan Hasil Inputan User
         * Akan Menghasilkan Luas Persegi Panjang
         */

         System.out.println("****************");
         System.out.println("Program Hitung Luas");
         System.out.println("****************");
         System.out.println("Panjang Adalah :"+p);
         System.out.println("Lebar Adalah :"+l);
         System.out.println("Luas Adalah :"+L);
    }
}
