public class Rangkuman1 {
    public static void main(String[] args){
    // void karena tidak ada fungsi yang membalikkan nilai
    // main karena hanya satu file
        int bilangan1,bilangan2;
        int jumlah;
    //int = tipe data, bilangan1&2 = nama variabel 
        bilangan1=10;
        bilangan2=20;
        jumlah=bilangan1+bilangan2;
        
    //Beda baris 
        System.out.println("Penjumlahan bil1 dan bil2 = "+jumlah);

    // Satu baris
        System.out.print("Penjumlahan bil1 dan bil2 = "+jumlah);
    }
}