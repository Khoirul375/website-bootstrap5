/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo2;

/**
 *
 * @author rplka
 */
public class Pbo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // BIO DATA SISWA
        // Nama     :   (String)
        // NIS      :   (int) 
        // Kelas    :   (String)
        // Jurusan  :   (String)
        // JenKel   :   (char/String)
        // Alamat   :   (String)
        
        // =======================
        // BIODATA SISWA
        // =======================
        String nama="Khoirul Anwar";
        int nis=206172;
        String kelas="XI RPL 2";
        String jurusan="RPL";
        char jenkel='L';
        String alamat="Ds.Cempereng";
        
        // output
        System.out.println("=============");
        System.out.println("BIODATA SISWA");
        System.out.println("=============");
        
        System.out.println("Nama = "+nama);
        System.out.println("NIS = "+nis);
        System.out.println("Kelas = "+kelas);
        System.out.println("Jurusan = "+jurusan);
        System.out.println("Jenis Kelamin = "+jenkel);
        System.out.println("Alamat = "+alamat);
    }
    
}
