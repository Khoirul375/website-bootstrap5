/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo1;

/**
 *
 * @author rplka
 */
public class Pbo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int angka=10; // variabel angka bil bulat
        double angka1=10.5; // variabel angka bil pecahan
        String nama="Amat"; // variabel nama tipe string
        char karakter='a'; // variabel karakter
        // output
        System.out.println(angka);
        System.out.println(angka1);
        System.out.println(nama);
        System.out.println(karakter);
        
        System.out.println("Variabel angka = "+angka+" Tahun");        
    }
    
}
