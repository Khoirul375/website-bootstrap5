/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo3;

/**
 *
 * @author rplka
 */
public class Pbo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // operasi aritmatiks :
        // penjumlahan
        // pengurangan
        // perkalian
        // pembagian
        
        int bilangan1,bilangan2;
        int jumlah;
        
        bilangan1=10;
        bilangan2=20;
        jumlah=bilangan1+bilangan2;
        
        
        System.out.println("Penjumlahan bil1 dan bil2 = "+jumlah);
    }
    
}
